README
-----------------

Lancement de projet :
          - Initialisation des composants de l'application
                            $ docker-compose up

          - Utilisation de l'application (Page d'accueil) :
                  Sur votre navigateur web : http://localhost:3000


Test :

  Lien des tests de validation automatique avec Travis :
  (Cliquez sur le bouton ci-dessous)
  
   [![Build Status](https://travis-ci.org/MartialDuv/CdP-2018-1_4.svg?branch=master)](https://travis-ci.org/MartialDuv/CdP-2018-1_4)
