Explication de l'arborescence
=============================

Racine
-------
Les fichiers de configuration suivants : 
- Docker
- Travis
- package.json

Le backlog du projet, un README à consulter pour les indications d'utilisation.

burnDownChart
------------
Les burndownchart du projet.

sprint
------------
Les différents fichiers de sprint contenant les tâches et les issues associées.

src
-----
Le code source du projet divisé dans les sous-dossiers suivants :
- /js :
le code javascript du projet.

- /sql :
le script de création de la base de données.

- /views :
le code ejs du projet.

tests
------
Les tests E2E du code source du projet et sont exécutés automatiquement par Travis.

spec
------
Les spécifications de l'arborescence de notre projet.