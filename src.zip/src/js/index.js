document.getElementById("button-redirect").addEventListener('click', redirect_creaprojet);

function redirect_creaprojet() {
    window.location.href = "../html/creaproject.html";
}